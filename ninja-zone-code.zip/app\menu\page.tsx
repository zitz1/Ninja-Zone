import { CustomerShell } from "@/components/customer-shell";

const menu = [
  ["01", "مشروبات", "قهوة، مشروبات باردة وطاقة"],
  ["02", "سناك", "اختيارات سريعة بين الجولات"],
  ["03", "وجبات", "وجبات خفيفة قابلة للإدارة من الكاشير"],
  ["04", "عروض", "العروض الموسمية التي يضيفها المدير"],
];

export default function MenuPage() {
  return <CustomerShell><main className="nz-container nz-page-shell"><div className="nz-page-hero"><span className="nz-label">THE MENU</span><h1>المنيو</h1><p>قسم مستقل عن الحجز. الأسعار والأصناف النهائية نربطها لاحقًا من لوحة الإدارة.</p></div><div className="nz-menu-page-grid">{menu.map(([n, t, s]) => <article key={n}><span>{n}</span><h2>{t}</h2><p>{s}</p><button>قريبًا</button></article>)}</div></main></CustomerShell>;
}
