"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const nav = [
  { href: "/", label: "الرئيسية", icon: "⌂" },
  { href: "/sections", label: "الأقسام", icon: "▦" },
  { href: "/bookings", label: "حجوزاتي", icon: "▣" },
  { href: "/menu", label: "المنيو", icon: "☷" },
  { href: "/support", label: "الدعم والمساعدة", icon: "◌" },
  { href: "/account", label: "حسابي", icon: "♙" },
];

export function CustomerShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [languageOpen, setLanguageOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const active = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <div className="nz-app">
      <div className="nz-ambient nz-ambient-a" />
      <div className="nz-ambient nz-ambient-b" />
      <div className="nz-noise" />

      <aside className="nz-sidebar">
        <Link href="/" className="nz-sidebar-brand" aria-label="Ninja Zone">
          <img src="/ninja-zone-logo.png" alt="Ninja Zone" />
        </Link>

        <nav className="nz-side-nav" aria-label="التنقل الرئيسي">
          {nav.map((item) => (
            <Link key={item.href} href={item.href} className={active(item.href) ? "active" : ""}>
              <span className="nz-side-icon">{item.icon}</span>
              <span>{item.label}</span>
              {active(item.href) && <i aria-hidden="true" />}
            </Link>
          ))}
        </nav>

        <Link href="/sections" className="nz-sidebar-book">احجز الآن <span>▣</span></Link>

        <div className="nz-sidebar-hours">
          <small>ساعات العمل</small>
          <strong>10:00 صباحًا — 3:00 فجرًا</strong>
          <span><i /> مفتوح جميع أيام الأسبوع</span>
        </div>

        <div className="nz-sidebar-social" aria-label="روابط التواصل">
          <span>◎</span><span>◉</span><span>◌</span><span>◍</span>
        </div>
      </aside>

      <div className="nz-main">
        <header className="nz-topbar">
          <div className="nz-top-controls">
            <button className="nz-mobile-menu" aria-label="فتح القائمة">☰</button>
            <div className="nz-notification-wrap">
              <button className="nz-icon-button" onClick={() => setNotificationsOpen((v) => !v)} aria-label="الإشعارات" aria-expanded={notificationsOpen}>
                ♧<b>3</b>
              </button>
              {notificationsOpen && (
                <div className="nz-dropdown nz-notification-dropdown">
                  <strong>الإشعارات</strong>
                  <p>لديك 3 إشعارات جديدة.</p>
                  <button onClick={() => setNotificationsOpen(false)}>إغلاق</button>
                </div>
              )}
            </div>
          </div>

          <label className="nz-search">
            <span>⌕</span>
            <input placeholder="إبحث عن جهاز أو قسم..." aria-label="البحث" />
          </label>

          <div className="nz-top-actions">
            <div className="nz-language-wrap">
              <button className="nz-lang" onClick={() => setLanguageOpen((v) => !v)} aria-expanded={languageOpen}>
                <span>◎</span> العربية <b>⌄</b>
              </button>
              {languageOpen && (
                <div className="nz-dropdown nz-language-dropdown">
                  <button className="selected" onClick={() => setLanguageOpen(false)}>✓ العربية</button>
                  <button onClick={() => setLanguageOpen(false)}>🇬🇧 English</button>
                </div>
              )}
            </div>
            <Link href="/account" className="nz-account-top"><span>♙</span> حسابي</Link>
          </div>
        </header>

        <div className="nz-mobile-brand"><Link href="/" aria-label="Ninja Zone"><img src="/ninja-zone-logo.png" alt="Ninja Zone" /></Link></div>
        {children}

        <footer className="nz-footer nz-container">
          <div><strong>NINJA ZONE</strong><small>Gaming Center • Ramadi</small></div>
          <div><span>10:00 صباحًا — 3:00 فجرًا</span><span>© {new Date().getFullYear()} Ninja Zone</span></div>
        </footer>
      </div>

      <nav className="nz-bottom-nav" aria-label="تنقل الهاتف">
        {nav.map((item) => (
          <Link key={item.href} href={item.href} className={active(item.href) ? "active" : ""}>
            <span>{item.icon}</span><small>{item.label.replace("والمساعدة", "")}</small>
          </Link>
        ))}
      </nav>
    </div>
  );
}
