"use client";

import { useState } from "react";
import Link from "next/link";
import { CustomerShell } from "@/components/customer-shell";

export default function BookingsPage() {
  const [notice, setNotice] = useState("");
  return <CustomerShell><main className="nz-container nz-page-shell"><div className="nz-page-hero"><span className="nz-label">MY BOOKINGS</span><h1>حجوزاتي</h1><p>هنا راح تكون كل حجوزاتك الحالية والسابقة، مع حالة الطلب ووقت الحضور والأجهزة.</p></div><div className="nz-empty-page"><div className="nz-empty-mark">◷</div><h2>ما عندك حجوزات محفوظة على هذا الجهاز</h2><p>بعد تفعيل الحساب والـOTP، هذه الصفحة راح تعرض حجوزاتك الحقيقية من قاعدة البيانات.</p><Link className="nz-btn nz-btn-primary" href="/sections">ابدأ أول حجز ↗</Link>{notice && <button className="nz-text-link" onClick={() => setNotice("")}>{notice}</button>}</div></main></CustomerShell>;
}
