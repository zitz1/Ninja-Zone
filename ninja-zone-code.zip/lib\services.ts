export type ResourceType = "PC_NORMAL" | "PC_MASTER" | "PS5" | "CINEMA" | "BILLIARD" | "TABLE";

export type Service = {
  type: ResourceType;
  title: string;
  arTitle: string;
  description: string;
  price: number;
  unit: string;
  count: number;
  tone: "cyan" | "violet" | "pink" | "blue";
  icon: string;
  image: string;
};

export const SERVICES: Service[] = [
  { type: "PC_NORMAL", title: "PC NORMAL", arTitle: "PC عادي", description: "جلسات يومية، سريعة ومريحة", price: 2500, unit: "ساعة", count: 8, tone: "cyan", icon: "01", image: "/card/pc-normal.jpg" },
  { type: "PC_MASTER", title: "PC MASTER", arTitle: "PC ماستر", description: "عتاد أقوى وتجربة VIP", price: 4000, unit: "ساعة", count: 8, tone: "violet", icon: "02", image: "/card/pc-master.jpg" },
  { type: "PS5", title: "PLAYSTATION 5", arTitle: "PlayStation 5", description: "10 أجهزة للعب الفردي والجماعي", price: 5000, unit: "ساعة", count: 10, tone: "blue", icon: "03", image: "/card/ps5.jpg" },
  { type: "CINEMA", title: "CINEMA ROOMS", arTitle: "غرف السينما", description: "غرفة خاصة بالكامل لك ولأصدقائك", price: 12000, unit: "ساعة", count: 4, tone: "pink", icon: "04", image: "/card/cinema.jpg" },
  { type: "BILLIARD", title: "BILLIARD", arTitle: "بليارد", description: "طاولتان • حجز بالساعة", price: 1000, unit: "ساعة", count: 2, tone: "cyan", icon: "05", image: "/card/billiard.jpg" },
  { type: "TABLE", title: "TABLES", arTitle: "الطاولات", description: "8 طاولات • قسم مستقل", price: 5000, unit: "ساعة", count: 8, tone: "violet", icon: "06", image: "/card/tables.jpg" },
];

export function getService(type: string) {
  return SERVICES.find((service) => service.type === type);
}

export function formatIQD(value: number) {
  return `${new Intl.NumberFormat("ar-IQ").format(value)} د.ع`;
}

export function formatDuration(minutes: number) {
  if (minutes < 60) return `${minutes} دقيقة`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins ? `${hours}:${String(mins).padStart(2, "0")} ساعة` : `${hours} ساعة`;
}
