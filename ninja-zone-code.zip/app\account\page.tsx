import Link from "next/link";
import { CustomerShell } from "@/components/customer-shell";

export default function AccountPage() {
  return <CustomerShell><main className="nz-container nz-page-shell"><div className="nz-page-hero"><span className="nz-label">MY ACCOUNT</span><h1>حسابي</h1><p>تسجيل الدخول سيكون برقم الهاتف + OTP، وبعدها تظهر بياناتك وحجوزاتك الحقيقية.</p></div><div className="nz-account-page"><div className="nz-account-head"><div className="nz-account-avatar">N</div><div><strong>عميل Ninja Zone</strong><small>غير مسجل دخول</small></div></div><div className="nz-login-box"><span className="nz-label">PHONE + OTP</span><h2>سجل دخولك بسرعة</h2><p>بعد تفعيل المصادقة، يصل OTP عبر قناة WhatsApp المحددة للمركز.</p><button className="nz-btn nz-btn-primary">تسجيل الدخول ↗</button><Link href="/bookings" className="nz-account-link">حجوزاتي <span>↗</span></Link></div></div></main></CustomerShell>;
}
