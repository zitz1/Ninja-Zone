"use client";

import { useState } from "react";
import { CustomerShell } from "@/components/customer-shell";

export default function SupportPage() {
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState(false);
  return <CustomerShell><main className="nz-container nz-page-shell"><div className="nz-page-hero"><span className="nz-label">LIVE SUPPORT</span><h1>الدعم</h1><p>إذا صار عندك استفسار عن الحجز أو الوقت أو الخدمات، اكتب لنا هنا.</p></div><div className="nz-support-grid"><div className="nz-support-card"><span className="nz-support-status"><i className="nz-live-dot" /> الدعم متاح</span><h2>دردشة Ninja Zone</h2><p>هنا نجهز الدردشة الحقيقية وربطها لاحقًا بواتساب الدعم.</p><div className="nz-chat-bubble">هلا 👋 شلون نساعدك اليوم؟</div><div className="nz-chat-bubble mine">أحتاج مساعدة بالحجز.</div><div className="nz-chat-actions"><button onClick={() => setMessage("مواعيد العمل: 10 صباحًا إلى 3 فجرًا")}>ساعات العمل</button><button onClick={() => setMessage("واتساب الدعم سيُربط بواجهة Business API")}>واتساب</button><button onClick={() => setMessage("اختر القسم ثم الوقت والمدة والأجهزة المتاحة")}>طريقة الحجز</button></div></div><div className="nz-support-form"><label>رسالتك<textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="اكتب رسالتك..." /></label><button className="nz-btn nz-btn-primary" onClick={() => { setSent(true); setMessage(""); }}>إرسال الرسالة ↗</button>{sent && <p>تم حفظ الرسالة للواجهة التجريبية. ربط المحادثة الحقيقية سيكون في مرحلة الدعم وWhatsApp.</p>}</div></div></main></CustomerShell>;
}
