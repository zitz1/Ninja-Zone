import { NextRequest, NextResponse } from "next/server";
import { ResourceType } from "@prisma/client";
import {
  BookingValidationError,
  getAvailability,
  makeIraqDate,
} from "@/lib/booking-engine";

function isResourceType(value: string): value is ResourceType {
  return Object.values(ResourceType).includes(value as ResourceType);
}

export async function GET(request: NextRequest) {
  try {
    const type = request.nextUrl.searchParams.get("type");
    const date = request.nextUrl.searchParams.get("date");
    const time = request.nextUrl.searchParams.get("time");
    const duration = Number(request.nextUrl.searchParams.get("duration") ?? "30");

    if (!type || !isResourceType(type)) {
      return NextResponse.json({ error: "Invalid resource type." }, { status: 400 });
    }
    if (!date || !time) {
      return NextResponse.json({ error: "date and time are required." }, { status: 400 });
    }
    if (!Number.isInteger(duration) || duration < 30 || duration % 30 !== 0) {
      return NextResponse.json({ error: "Duration must be a multiple of 30 minutes." }, { status: 400 });
    }

    const startAt = makeIraqDate(date, time);
    const endAt = new Date(startAt.getTime() + duration * 60_000);
    const result = await getAvailability(type, startAt, endAt);

    return NextResponse.json({ ...result, type, startAt, endAt, durationMinutes: duration });
  } catch (error: unknown) {
    if (error instanceof BookingValidationError) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    console.error("Availability error:", error);
    return NextResponse.json({ error: "Unable to check availability." }, { status: 500 });
  }
}
