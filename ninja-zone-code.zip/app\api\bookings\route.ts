import { NextRequest, NextResponse } from "next/server";
import { createPendingBooking, BookingValidationError, type BookingRequestItem } from "@/lib/booking-engine";

export async function POST(request: NextRequest) {
  try {
    const userId = process.env.NODE_ENV === "production" ? null : request.headers.get("x-demo-user-id");

    if (!userId) {
      return NextResponse.json({ error: "Authentication is required. OTP/session authentication will be connected in the auth phase." }, { status: 401 });
    }

    const body = (await request.json()) as { items?: BookingRequestItem[]; customerNote?: string };

    if (!Array.isArray(body.items) || body.items.length === 0) {
      return NextResponse.json({ error: "items are required." }, { status: 400 });
    }

    const booking = await createPendingBooking(userId, body.items, body.customerNote);

    return NextResponse.json({
      booking,
      message: "Booking request created and is waiting for cashier approval.",
    }, { status: 201 });
  } catch (error: unknown) {
    if (error instanceof BookingValidationError) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    console.error("Booking creation error:", error);
    return NextResponse.json({ error: "Unable to create booking." }, { status: 500 });
  }
}
