"use client";

import { useEffect, useMemo, useState } from "react";
import type { Service } from "@/lib/services";
import { formatDuration, formatIQD } from "@/lib/services";

type AvailableResource = { id: string; code: string; name: string; available: boolean; status: string };

function dateKey(date: Date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}
function timeMinutes(value: string) { const [h, m] = value.split(":").map(Number); return h * 60 + m; }
function iso(date: string, time: string) { return `${date}T${time}:00+03:00`; }
function displayTime(value: string) {
  const [hour, minute] = value.split(":").map(Number);
  const suffix = hour < 12 ? "صباحًا" : "مساءً";
  const h = hour % 12 || 12;
  return `${String(h).padStart(2, "0")}:${String(minute).padStart(2, "0")} ${suffix}`;
}

const slots = Array.from({ length: 35 }, (_, i) => {
  const mins = 10 * 60 + i * 30;
  const normalized = mins % (24 * 60);
  return `${String(Math.floor(normalized / 60)).padStart(2, "0")}:${String(normalized % 60).padStart(2, "0")}`;
});

export function BookingFlow({ service }: { service: Service }) {
  const [date, setDate] = useState(dateKey(new Date()));
  const [time, setTime] = useState("");
  const [timeOpen, setTimeOpen] = useState(false);
  const [duration, setDuration] = useState(30);
  const [resources, setResources] = useState<AvailableResource[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [notice, setNotice] = useState("");
  const [sent, setSent] = useState(false);

  const dates = useMemo(() => Array.from({ length: 7 }, (_, index) => {
    const d = new Date(); d.setHours(12, 0, 0, 0); d.setDate(d.getDate() + index);
    return { key: dateKey(d), day: new Intl.DateTimeFormat("ar-IQ", { weekday: "short" }).format(d), number: d.getDate(), month: new Intl.DateTimeFormat("ar-IQ", { month: "short" }).format(d) };
  }), []);

  const isToday = date === dateKey(new Date());
  const nowMinutes = new Date().getHours() * 60 + new Date().getMinutes();
  const total = service.price * duration / 60 * Math.max(1, selected.length);
  const availableCount = resources.filter((r) => r.available).length;

  useEffect(() => {
    if (!time) { setResources([]); setSelected([]); return; }
    const controller = new AbortController();
    async function run() {
      setLoading(true); setNotice("");
      try {
        const params = new URLSearchParams({ type: service.type, date, time, duration: String(duration) });
        const res = await fetch(`/api/availability?${params.toString()}`, { cache: "no-store", signal: controller.signal });
        const data = await res.json();
        if (!res.ok) throw new Error(data?.error ?? "تعذر تحديث التوفر");
        const next = Array.isArray(data.resources) ? data.resources : [];
        setResources(next);
        setSelected((current) => current.filter((id) => next.some((r: AvailableResource) => r.id === id && r.available)));
      } catch (error) {
        if (error instanceof Error && error.name !== "AbortError") setNotice(error.message);
      } finally { if (!controller.signal.aborted) setLoading(false); }
    }
    run(); return () => controller.abort();
  }, [service.type, date, time, duration]);

  function toggleResource(id: string) {
    const resource = resources.find((r) => r.id === id);
    if (!resource?.available) return;
    setSelected((current) => current.includes(id) ? current.filter((x) => x !== id) : [...current, id]);
  }

  async function submit() {
    if (!time || selected.length === 0) { setNotice("اختار وقت الحضور وجهازًا واحدًا على الأقل."); return; }
    setSubmitting(true); setNotice("");
    try {
      const demo = await fetch("/api/dev/demo-user", { method: "POST" });
      const user = await demo.json();
      if (!demo.ok) throw new Error(user?.error ?? "تعذر تجهيز الحساب التجريبي");
      const response = await fetch("/api/bookings", {
        method: "POST", headers: { "Content-Type": "application/json", "x-demo-user-id": user.id },
        body: JSON.stringify({ items: [{ resourceType: service.type, startAt: iso(date, time), durationMinutes: duration, quantity: selected.length, resourceIds: selected }] }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data?.error ?? "تعذر إرسال الطلب");
      setSent(true); setNotice(`تم إرسال طلب الحجز #${String(data.booking.id).slice(-6)}. بانتظار تأكيد الكاشير لمدة 15 دقيقة.`);
    } catch (error) { setNotice(error instanceof Error ? error.message : "حدث خطأ غير متوقع"); }
    finally { setSubmitting(false); }
  }

  if (sent) return <section className="nz-container nz-page-shell"><div className="nz-success-card"><div className="nz-success-mark">✓</div><span className="nz-label">REQUEST SENT</span><h1>طلبك وصل للكاشير</h1><p>{notice}</p><div className="nz-success-grid"><div><small>القسم</small><strong>{service.arTitle}</strong></div><div><small>وقت الحضور</small><strong>{displayTime(time)}</strong></div><div><small>المدة</small><strong>{formatDuration(duration)}</strong></div><div><small>الأجهزة</small><strong>{selected.length}</strong></div></div><div className="nz-inline-actions"><a className="nz-btn nz-btn-primary" href="/bookings">مشاهدة حجوزاتي</a><a className="nz-btn nz-btn-ghost" href="/sections">العودة للأقسام</a></div></div></section>;

  return (
    <main className="nz-container nz-booking-page">
      <div className="nz-booking-head">
        <a href="/sections" className="nz-back-link">← الأقسام</a>
        <div><span className={`nz-kicker tone-${service.tone}`}>{service.title}</span><h1>احجز <span>{service.arTitle}</span></h1><p>اختار يوم الحجز، ثم اضغط على وقت الحضور لاختيار الموعد. بعدها تظهر لك الأجهزة المتوفرة وتختار جهازًا أو أكثر.</p></div>
      </div>

      <section className="nz-booking-card">
        <div className="nz-progress">
          {[["01", "القسم"], ["02", "وقت الحضور"], ["03", "الأجهزة"], ["04", "المدة"], ["05", "تأكيد الحجز"]].map(([num, label], i) => <div key={num} className={i < 2 || (i === 2 && selected.length > 0) ? "active" : ""}><b>{i === 0 ? "✓" : num}</b><span>{label}</span></div>)}
        </div>

        <div className="nz-booking-grid">
          <div className="nz-book-main">
            <section className="nz-book-section">
              <div className="nz-book-section-title"><b>01</b><div><strong>اختار تاريخ الحضور</strong><small>الحجز متاح خلال الأيام السبعة القادمة</small></div></div>
              <div className="nz-date-row">
                {dates.map((item) => <button key={item.key} className={date === item.key ? "active" : ""} onClick={() => { setDate(item.key); setTime(""); setTimeOpen(false); setSelected([]); }}><small>{item.day}</small><strong>{item.number}</strong><em>{item.month}</em></button>)}
              </div>
            </section>

            <section className="nz-book-section">
              <div className="nz-book-section-title"><b>02</b><div><strong>وقت الحضور</strong><small>اضغط الزر لعرض الأوقات بشكل عمودي</small></div></div>
              <button className={`nz-time-trigger ${time ? "chosen" : ""}`} onClick={() => setTimeOpen((v) => !v)} aria-expanded={timeOpen}><span>◷</span><div><small>وقت الحضور</small><strong>{time ? displayTime(time) : "اختار وقت الحضور"}</strong></div><b>{timeOpen ? "⌃" : "⌄"}</b></button>
              {timeOpen && <div className="nz-time-menu">{slots.map((slot) => { const past = isToday && timeMinutes(slot) <= nowMinutes; return <button key={slot} disabled={past} className={time === slot ? "active" : ""} onClick={() => { setTime(slot); setSelected([]); setTimeOpen(false); }}>{displayTime(slot)}<span>30 دقيقة</span></button>; })}</div>}
            </section>

            <section className="nz-book-section">
              <div className="nz-book-section-title"><b>03</b><div><strong>اختار الجهاز</strong><small>{!time ? "بعد اختيار الوقت ستظهر الأجهزة" : loading ? "جاري تحديث حالة الأجهزة..." : `${resources.length} أجهزة • ${availableCount} متاح`}</small></div><em>{selected.length} مختار</em></div>
              {!time ? <div className="nz-empty-book">اختار وقت الحضور أولًا حتى نعرض لك كل الأجهزة المتوفرة لهذا الموعد.</div> : loading ? <div className="nz-empty-book">جاري التحقق من الحجوزات...</div> : resources.length === 0 ? <div className="nz-empty-book">لا توجد أجهزة لهذا القسم في الوقت المحدد.</div> : <div className="nz-resource-grid">{resources.map((resource) => <button key={resource.id} disabled={!resource.available} onClick={() => toggleResource(resource.id)} className={`nz-resource-card ${resource.available ? "available" : "busy"} ${selected.includes(resource.id) ? "selected" : ""}`}><span className="nz-resource-code">{resource.code}</span><strong>{resource.name || service.arTitle}</strong><small>{resource.available ? "متاح" : "محجوز"}</small>{selected.includes(resource.id) && <b className="nz-resource-check">✓</b>}</button>)}</div>}
            </section>

            <section className="nz-book-section nz-duration-section">
              <div className="nz-book-section-title"><b>04</b><div><strong>المدة</strong><small>الحد الأدنى 30 دقيقة</small></div></div>
              <div className="nz-duration-control"><button onClick={() => setDuration((v) => Math.max(30, v - 30))}>−</button><div><strong>{formatDuration(duration)}</strong><small>{formatIQD(service.price * duration / 60)} للجهاز الواحد</small></div><button onClick={() => setDuration((v) => v + 30)}>+</button></div>
            </section>
          </div>

          <aside className="nz-book-preview">
            <div className="nz-preview-image"><img src={service.image} alt={service.arTitle} /><span>{service.count} أجهزة</span></div>
            <div className="nz-preview-body"><span className="nz-label">SELECTED SERVICE</span><h2>{service.arTitle}</h2><p>{service.description}</p><div className="nz-preview-price"><small>السعر / ساعة</small><strong>{formatIQD(service.price)}</strong></div></div>
            <div className="nz-preview-summary"><div><span>وقت الحضور</span><strong>{time ? displayTime(time) : "لم يتم الاختيار"}</strong></div><div><span>الأجهزة</span><strong>{selected.length} من {service.count}</strong></div><div><span>المدة</span><strong>{formatDuration(duration)}</strong></div></div>
            <div className="nz-total"><span>الإجمالي المتوقع</span><strong>{formatIQD(total)}</strong><small>{selected.length || 0} أجهزة • {formatDuration(duration)}</small></div>
          </aside>
        </div>

        {notice && <div className="nz-inline-notice">{notice}</div>}
        <div className="nz-book-actions"><a href="/sections" className="nz-btn nz-btn-ghost">رجوع</a><button className="nz-btn nz-btn-primary" disabled={!time || selected.length === 0 || loading || submitting} onClick={submit}>{submitting ? "جاري الإرسال..." : "إرسال طلب الحجز ↗"}</button></div>
        <p className="nz-policy-note">الطلب يبقى معلّقًا 15 دقيقة بانتظار الكاشير. الدفع عند الوصول.</p>
      </section>
    </main>
  );
}
