import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { UserRole } from "@prisma/client";

export async function POST() {
  if (process.env.NODE_ENV === "production") {
    return NextResponse.json({ error: "Development endpoint disabled in production." }, { status: 404 });
  }

  const user = await prisma.user.upsert({
    where: { phone: "+9647700000000" },
    update: { name: "Ninja Zone Demo", role: UserRole.CUSTOMER, isActive: true },
    create: { phone: "+9647700000000", name: "Ninja Zone Demo", role: UserRole.CUSTOMER },
    select: { id: true },
  });

  return NextResponse.json(user);
}
