import { Prisma, ResourceType, BookingStatus, ResourceStatus } from "@prisma/client";
import { prisma } from "./prisma";

export const MIN_BOOKING_MINUTES = 30;
export const SLOT_MINUTES = 30;
export const MAX_BOOKING_DAYS = 7;
export const PENDING_TTL_MINUTES = 15;
export const GRACE_PERIOD_MINUTES = 15;
export const BUSINESS_OPEN_HOUR = 10;
export const BUSINESS_CLOSE_HOUR = 3;
export const IRAQ_OFFSET = "+03:00";

const ACTIVE_BOOKING_STATUSES: BookingStatus[] = [
  BookingStatus.PENDING,
  BookingStatus.CONFIRMED,
  BookingStatus.ACTIVE,
];

export type BookingRequestItem = {
  resourceType: ResourceType;
  startAt: string;
  durationMinutes: number;
  quantity?: number;
  resourceIds?: string[];
};

export type NormalizedBookingItem = {
  resourceType: ResourceType;
  startAt: Date;
  endAt: Date;
  durationMinutes: number;
  quantity: number;
  resourceIds?: string[];
};

function assertDate(value: string, label: string): Date {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    throw new BookingValidationError(`${label} is not a valid ISO date/time.`);
  }
  return date;
}

export class BookingValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "BookingValidationError";
  }
}

function iraqClockMinutes(date: Date) {
  const shifted = new Date(date.getTime() + 3 * 60 * 60_000);
  const hours = shifted.getUTCHours();
  const minutes = shifted.getUTCMinutes();
  return hours * 60 + minutes < BUSINESS_OPEN_HOUR * 60
    ? hours * 60 + minutes + 24 * 60
    : hours * 60 + minutes;
}

function assertBusinessHours(startAt: Date, endAt: Date) {
  const start = iraqClockMinutes(startAt);
  const end = iraqClockMinutes(endAt);
  const open = BUSINESS_OPEN_HOUR * 60;
  const close = 24 * 60 + BUSINESS_CLOSE_HOUR * 60;

  if (start < open || end > close || end <= start) {
    throw new BookingValidationError("This booking must fit within Ninja Zone hours (10:00 AM–3:00 AM)." );
  }
}

export function normalizeBookingItems(items: BookingRequestItem[]): NormalizedBookingItem[] {
  if (!Array.isArray(items) || items.length === 0) {
    throw new BookingValidationError("At least one booking item is required.");
  }

  return items.map((item) => {
    const quantity = item.quantity ?? 1;
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 50) {
      throw new BookingValidationError("Quantity must be an integer from 1 to 50.");
    }

    const durationMinutes = item.durationMinutes;
    if (
      !Number.isInteger(durationMinutes) ||
      durationMinutes < MIN_BOOKING_MINUTES ||
      durationMinutes % SLOT_MINUTES !== 0
    ) {
      throw new BookingValidationError("Duration must be at least 30 minutes and use 30-minute steps.");
    }

    const startAt = assertDate(item.startAt, "startAt");
    const endAt = new Date(startAt.getTime() + durationMinutes * 60_000);
    const now = new Date();
    const latestAllowed = new Date(now.getTime() + MAX_BOOKING_DAYS * 24 * 60 * 60_000);

    if (startAt <= now) {
      throw new BookingValidationError("Booking start time must be in the future.");
    }

    if (startAt > latestAllowed) {
      throw new BookingValidationError("Bookings can only be made up to 7 days ahead.");
    }

    assertBusinessHours(startAt, endAt);

    const resourceIds = Array.isArray(item.resourceIds)
      ? [...new Set(item.resourceIds.filter((id): id is string => typeof id === "string" && id.trim().length > 0))]
      : undefined;

    if (resourceIds && resourceIds.length > 0 && resourceIds.length !== quantity) {
      throw new BookingValidationError("Selected device count must match the requested quantity.");
    }

    return { resourceType: item.resourceType, startAt, endAt, durationMinutes, quantity, resourceIds };
  });
}

async function expirePendingBookings(tx: Prisma.TransactionClient, now: Date) {
  await tx.booking.updateMany({
    where: {
      status: BookingStatus.PENDING,
      expiresAt: { lt: now },
    },
    data: {
      status: BookingStatus.EXPIRED,
    },
  });
}

function overlaps(startAt: Date, endAt: Date, otherStart: Date, otherEnd: Date) {
  return startAt < otherEnd && endAt > otherStart;
}

async function allocateResources(
  tx: Prisma.TransactionClient,
  item: NormalizedBookingItem,
  requestedResourceIds?: string[],
) {
  const requestedIds = [...new Set(requestedResourceIds ?? [])];

  if (requestedIds.length > 0 && requestedIds.length !== item.quantity) {
    throw new BookingValidationError("Selected device count must match the requested quantity.");
  }

  const resources = await tx.resource.findMany({
    where: {
      id: requestedIds.length > 0 ? { in: requestedIds } : undefined,
      type: item.resourceType,
      isActive: true,
      status: {
        in: [ResourceStatus.AVAILABLE, ResourceStatus.RESERVED, ResourceStatus.PLAYING],
      },
    },
    orderBy: { code: "asc" },
    select: { id: true, code: true, status: true },
  });

  if (resources.length < item.quantity) {
    if (requestedIds.length > 0) {
      throw new BookingValidationError("One or more selected devices are no longer available.");
    }
    throw new BookingValidationError(`Not enough ${item.resourceType} resources are configured.`);
  }

  const resourceIds = resources.map((resource) => resource.id);

  const conflicts = await tx.bookingItem.findMany({
    where: {
      resourceId: { in: resourceIds },
      startAt: { lt: item.endAt },
      endAt: { gt: item.startAt },
      booking: {
        status: { in: ACTIVE_BOOKING_STATUSES },
        OR: [
          { status: { not: BookingStatus.PENDING } },
          { status: BookingStatus.PENDING, expiresAt: { gt: new Date() } },
        ],
      },
    },
    select: {
      resourceId: true,
      startAt: true,
      endAt: true,
    },
  });

  const blocked = new Set(
    conflicts
      .filter((conflict) => conflict.resourceId && overlaps(item.startAt, item.endAt, conflict.startAt, conflict.endAt))
      .map((conflict) => conflict.resourceId as string),
  );

  const available = resources.filter((resource) => !blocked.has(resource.id));

  if (available.length < item.quantity) {
    throw new BookingValidationError(
      `Only ${available.length} ${item.resourceType} resource(s) are available for the selected time.`,
    );
  }

  if (requestedIds.length > 0 && available.length !== requestedIds.length) {
    throw new BookingValidationError("One or more selected devices are no longer available.");
  }

  return requestedIds.length > 0 ? available : available.slice(0, item.quantity);
}

export async function createPendingBooking(userId: string, items: BookingRequestItem[], customerNote?: string) {
  const normalized = normalizeBookingItems(items);
  let lastError: unknown;

  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      return await prisma.$transaction(
        async (tx) => {
          const now = new Date();
          await expirePendingBookings(tx, now);

          const pricing = await tx.pricing.findMany({
            where: {
              resourceType: { in: normalized.map((item) => item.resourceType) },
              active: true,
            },
          });

          const priceMap = new Map(pricing.map((p) => [p.resourceType, p.pricePerHour]));
          const allocated: Array<{
            resourceId: string;
            resourceType: ResourceType;
            startAt: Date;
            endAt: Date;
            durationMinutes: number;
            unitPrice: number;
            totalPrice: number;
          }> = [];

          for (const item of normalized) {
            const unitPrice = priceMap.get(item.resourceType);
            if (unitPrice === undefined) {
              throw new BookingValidationError(`No active price is configured for ${item.resourceType}.`);
            }

            const resources = await allocateResources(tx, item, item.resourceIds);

            for (const resource of resources) {
              const totalPrice = Math.round((unitPrice * item.durationMinutes) / 60);
              allocated.push({
                resourceId: resource.id,
                resourceType: item.resourceType,
                startAt: item.startAt,
                endAt: item.endAt,
                durationMinutes: item.durationMinutes,
                unitPrice,
                totalPrice,
              });
            }
          }

          const totalAmount = allocated.reduce((sum, item) => sum + item.totalPrice, 0);
          const expiresAt = new Date(now.getTime() + PENDING_TTL_MINUTES * 60_000);

          return tx.booking.create({
            data: {
              userId,
              status: BookingStatus.PENDING,
              startAt: normalized.reduce((min, item) => (item.startAt < min ? item.startAt : min), normalized[0].startAt),
              endAt: normalized.reduce((max, item) => (item.endAt > max ? item.endAt : max), normalized[0].endAt),
              totalAmount,
              customerNote: customerNote?.trim() || undefined,
              expiresAt,
              items: {
                create: allocated,
              },
            },
            include: {
              items: {
                include: { resource: true },
              },
            },
          });
        },
        { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
      );
    } catch (error) {
      lastError = error;
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2034") {
        continue;
      }
      throw error;
    }
  }

  throw lastError;
}

export async function getAvailability(resourceType: ResourceType, startAt: Date, endAt: Date) {
  assertBusinessHours(startAt, endAt);

  const resources = await prisma.resource.findMany({
    where: {
      type: resourceType,
      isActive: true,
      status: {
        in: [ResourceStatus.AVAILABLE, ResourceStatus.RESERVED, ResourceStatus.PLAYING],
      },
    },
    select: { id: true, code: true, name: true, status: true },
    orderBy: { code: "asc" },
  });

  const conflicts = await prisma.bookingItem.findMany({
    where: {
      resourceId: { in: resources.map((resource) => resource.id) },
      startAt: { lt: endAt },
      endAt: { gt: startAt },
      booking: {
        status: { in: ACTIVE_BOOKING_STATUSES },
        OR: [
          { status: { not: BookingStatus.PENDING } },
          { status: BookingStatus.PENDING, expiresAt: { gt: new Date() } },
        ],
      },
    },
    select: { resourceId: true },
  });

  const blocked = new Set(conflicts.map((conflict) => conflict.resourceId).filter(Boolean));
  const available = resources.filter((resource) => !blocked.has(resource.id));

  return {
    total: resources.length,
    available: available.length,
    canBook: available.length > 0,
    resources: resources.map((resource) => ({
      id: resource.id,
      code: resource.code,
      name: resource.name,
      status: resource.status,
      available: !blocked.has(resource.id),
    })),
  };
}

export function makeIraqDate(date: string, time: string): Date {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time)) {
    throw new BookingValidationError("Use date YYYY-MM-DD and time HH:mm.");
  }

  return assertDate(`${date}T${time}:00${IRAQ_OFFSET}`, "date/time");
}

export function generateBusinessDaySlots(businessDate: string): string[] {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(businessDate)) {
    throw new BookingValidationError("businessDate must use YYYY-MM-DD.");
  }

  const [year, month, day] = businessDate.split("-").map(Number);
  const start = new Date(Date.UTC(year, month - 1, day, BUSINESS_OPEN_HOUR - 3, 0, 0));
  const slots: string[] = [];

  for (let minutes = 0; minutes <= 17 * 60 + 30; minutes += SLOT_MINUTES) {
    const d = new Date(start.getTime() + minutes * 60_000);
    slots.push(d.toISOString());
  }

  return slots;
}
